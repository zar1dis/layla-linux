#!/bin/sh
set -eu

project_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
data_home=${XDG_DATA_HOME:-"$HOME/.local/share"}
app_home=$data_home/layla-linux
venv=$app_home/venv
applications_dir=${XDG_DATA_HOME:-"$HOME/.local/share"}/applications

python3 -m venv "$venv"
"$venv/bin/python" -m pip install --upgrade pip
"$venv/bin/python" -m pip install "$project_dir"
mkdir -p "$app_home/assets" "$applications_dir"

cat > "$applications_dir/layla-linux.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Layla
Comment=Walking desktop companion
Exec=$venv/bin/layla-linux
Icon=applications-graphics
Terminal=false
Categories=Utility;
EOF

printf 'Installed Layla. Add licensed idle_NNN.png and walk_NNN.png files to:\n%s\n' "$app_home/assets"
