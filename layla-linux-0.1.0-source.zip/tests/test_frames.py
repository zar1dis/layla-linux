from pathlib import Path
import tempfile
import unittest

from layla_linux.frames import load_frame_paths


class LoadFramePathsTests(unittest.TestCase):
    def test_loads_both_sequences_in_numeric_order(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for name in ("walk_001.png", "idle_001.png", "walk_000.png", "idle_000.png"):
                (root / name).touch()

            frames = load_frame_paths(root)

            self.assertEqual(
                [path.name for path in frames["walk"]],
                ["walk_000.png", "walk_001.png"],
            )
            self.assertEqual(
                [path.name for path in frames["idle"]],
                ["idle_000.png", "idle_001.png"],
            )

    def test_rejects_missing_sequence(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "walk_000.png").touch()

            with self.assertRaisesRegex(FileNotFoundError, "No idle"):
                load_frame_paths(root)

    def test_rejects_gaps(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for name in ("walk_000.png", "walk_002.png", "idle_000.png"):
                (root / name).touch()

            with self.assertRaisesRegex(ValueError, "contiguously"):
                load_frame_paths(root)


if __name__ == "__main__":
    unittest.main()
