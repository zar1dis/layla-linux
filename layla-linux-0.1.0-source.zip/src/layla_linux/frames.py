from pathlib import Path
import re


_FRAME_NAME = re.compile(r"^(?P<state>idle|walk)_(?P<index>\d+)\.png$")


def load_frame_paths(asset_dir: Path) -> dict[str, tuple[Path, ...]]:
    """Find contiguous idle and walk sprite sequences in an asset directory."""
    found: dict[str, list[tuple[int, Path]]] = {"idle": [], "walk": []}
    if not asset_dir.is_dir():
        raise FileNotFoundError(f"Sprite directory does not exist: {asset_dir}")

    for path in asset_dir.iterdir():
        match = _FRAME_NAME.fullmatch(path.name)
        if match and path.is_file():
            found[match["state"]].append((int(match["index"]), path))

    result: dict[str, tuple[Path, ...]] = {}
    for state, indexed_paths in found.items():
        indexed_paths.sort(key=lambda item: item[0])
        if not indexed_paths:
            raise FileNotFoundError(f"No {state}_NNN.png frames in {asset_dir}")
        indices = [index for index, _ in indexed_paths]
        expected = list(range(len(indices)))
        if indices != expected:
            raise ValueError(
                f"{state} frames must be numbered contiguously from 000; "
                f"found {indices[:8]}"
            )
        result[state] = tuple(path for _, path in indexed_paths)
    return result
