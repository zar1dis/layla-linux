"""Linux desktop companion for Layla."""

__version__ = "0.1.0"
