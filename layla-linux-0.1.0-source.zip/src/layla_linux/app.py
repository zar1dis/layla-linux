import argparse
import os
import sys
from pathlib import Path

from PySide6.QtCore import QPoint, Qt, QTimer
from PySide6.QtGui import QAction, QPainter, QPixmap
from PySide6.QtWidgets import QApplication, QMenu, QWidget

from .frames import load_frame_paths


class LaylaWindow(QWidget):
    frame_interval_ms = 40
    walking_speed = 44.0

    def __init__(self, asset_dir: Path) -> None:
        super().__init__()
        self.setWindowTitle("Layla")
        self.setWindowFlags(
            Qt.WindowType.Tool
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)

        paths = load_frame_paths(asset_dir)
        self.frames = {
            state: tuple(QPixmap(str(path)) for path in frame_paths)
            for state, frame_paths in paths.items()
        }
        for state, pixmaps in self.frames.items():
            if any(pixmap.isNull() for pixmap in pixmaps):
                raise ValueError(f"Could not decode one or more {state} PNG frames")

        screen = QApplication.primaryScreen()
        if screen is None:
            raise RuntimeError("No desktop screen is available")
        available = screen.availableGeometry()
        source_size = self.frames["idle"][0].size()
        self.scale = min(0.42, (available.height() * 0.46) / source_size.height())
        self.resize(
            max(1, round(source_size.width() * self.scale)),
            max(1, round(source_size.height() * self.scale)),
        )
        self.move(available.left(), available.bottom() - self.height() + 1)

        self.state = "walk"
        self.frame_index = 0
        self.direction = 1
        self._last_tick_ms = 0
        self._drag_offset: QPoint | None = None

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._advance)
        self.timer.start(self.frame_interval_ms)

    def _advance(self) -> None:
        sequence = self.frames[self.state]
        self.frame_index = (self.frame_index + 1) % len(sequence)

        if self.state == "walk":
            screen = QApplication.primaryScreen()
            if screen is not None:
                bounds = screen.availableGeometry()
                delta = max(1, round(self.walking_speed * self.frame_interval_ms / 1000))
                next_x = self.x() + self.direction * delta
                max_x = bounds.right() - self.width() + 1
                if next_x <= bounds.left() or next_x >= max_x:
                    self.direction *= -1
                    next_x = min(max(next_x, bounds.left()), max_x)
                self.move(next_x, self.y())
        self.update()

    def paintEvent(self, _event) -> None:
        pixmap = self.frames[self.state][self.frame_index]
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        if self.direction < 0:
            painter.translate(self.width(), 0)
            painter.scale(-1, 1)
        painter.drawPixmap(self.rect(), pixmap)

    def contextMenuEvent(self, event) -> None:
        menu = QMenu(self)
        walking = QAction("Walking", menu)
        walking.setCheckable(True)
        walking.setChecked(self.state == "walk")
        walking.triggered.connect(self._toggle_walking)
        menu.addAction(walking)
        menu.addSeparator()
        menu.addAction("Quit Layla", QApplication.quit)
        menu.exec(event.globalPos())

    def _toggle_walking(self, enabled: bool) -> None:
        self.state = "walk" if enabled else "idle"
        self.frame_index = 0
        self.update()

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event) -> None:
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_offset)
            event.accept()

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_offset = None
            event.accept()


def main() -> int:
    data_home = Path(os.environ.get("XDG_DATA_HOME", "~/.local/share")).expanduser()
    default_assets = data_home / "layla-linux" / "assets"
    parser = argparse.ArgumentParser(description="Run Layla's Linux sprite companion")
    parser.add_argument(
        "--assets",
        type=Path,
        default=default_assets,
        help=(
            "Directory containing idle_NNN.png and walk_NNN.png sprite frames "
            f"(default: {default_assets})"
        ),
    )
    args = parser.parse_args()

    app = QApplication(sys.argv)
    app.setApplicationName("Layla")
    try:
        window = LaylaWindow(args.assets.expanduser().resolve())
    except (FileNotFoundError, ValueError, RuntimeError) as error:
        parser.error(str(error))
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
